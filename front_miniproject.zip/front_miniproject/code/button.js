/**
 * 버튼 클릭할 때마다, 랜덤 이미지 배치 
 */

let randomNumber = Math.floor(Math.random() * 4) + 1;
document.querySelector('.img_box img')
    .setAttribute('src', '/images/bg0' + randomNumber + '.jpg');
