// // // Node.js, Express 패키지를 활용하여 간단한 서버 구성

// // // express 모듈을 설치했다고 해서 바로 사용할 수 잇는 것은 아님
// // // server.js에서 사용을 하려면 해당 모듈을 import해야함
// // const express = require('express'); // express 모듈 불러오기
// // const app = express(); // express app 인스턴스 생성

// // // 미들웨어 설정
// // app.use(express.static('public')); // 어떤 경로를 요청 -> 무언가 동작한다. 정적인 자원(static)은 public 폴더에 있다!

// // app.get('/', (resquest, response) => {
// //     response.sendFile('index.html');
// // })
// // // console.log('Hello'));

// // const port = 3000;
// // app.listen(port,
// //     () =>
// //         console.log(`http://127.0.0.1:3000/ app listening on port ${3000}`));




// // Node.js, Express 패키지를 활용하여 간단한 서버 구성

// //  express 모듈을 설치했다고 해서 바로 사용할 수 있는 것은 아님
// // server.js에서 사용을 하려면 해당 모듈을 import 해야함
// const express = require('express'); // express 모듈 불러오기
// const app = express(); // express app 인스턴스 생성

// const httpRequest = require('request');


// // TODO: .dotenv
// const clientID = 'f3mLWUkcA__b2fX4ks0q';
// const clientSecret = 'h8EPe9Ol5L'

// // 미들웨어 설정
// app.use(express.static('public')); // 정적인 자원(static)은 public 폴더에 있다!
// app.use(express.json()); // 역직렬화 처리용 모듈

// // 127.0.0.1:3000/ 경로(Root)로 접근했을 때 동작시킬 핸들러
// app.get('/', (request, response) => {
//     response.sendFile('index.html');
// });

// // TODO: 그 외에 언어 감지, 언어 번역 요청시 동작할 핸들러

// // 127.0.0.1:3000/detect 경로로 브라우저가 접근 시 동작할 핸들러
// app.post('/detect', (request, response) => {
//     console.log(request.body);
//     // 언어감지 요청을 위한 요청 메시지 구성정보
//     // 1.URL
//     const url = 'https://openapi.naver.com/v1/papago/detectLangs';

//     // 2. Body, Header 등 데이터
//     const options = {
//         url,
//         form: request.body,
//         headers: {
//             'Content-Type': 'application/json',
//             'X-Naver-Client-Id': clientID,
//             'X-Naver-Client-Secret': clientSecret,
//             // secret도 추가

//         }
//     }
//     httpRequest.post(options, (error, httpRequest, body) => {
//         if (!error && response.statusCode === 200) {
//             response.send(body); // 서버가 클라이언트로 데이터를 응답
//             console.log(body);
//         }
//     })
// });


// // 언어 번역 요청 부분

// app.post('/detect', (request, response) => {
//     curl "https://openapi.naver.com/v1/papago/detectLangs" \
//     -d "query=만나서 반갑습니다." \
//     -H "Content-Type: application/x-www-form-urlencoded; charset=UTF-8" \

// })

// curl "https://openapi.naver.com/v1/papago/detectLangs" \
// -d "query=만나서 반갑습니다." \
// -H "Content-Type: application/x-www-form-urlencoded; charset=UTF-8" \
// -H "X-Naver-Client-Id: {애플리케이션 등록 시 발급받은 클라이언트 아이디 값}" \
// -H "X-Naver-Client-Secret: {애플리케이션 등록 시 발급받은 클라이언트 시크릿 값}" - v


// const port = 3000;
// app.listen(port,
//     () =>
//         console.log(`http://127.0.0.1:3000/ app listening on port ${port}`));










/* answer code

*/

// Node.js, Express 패키지를 활용하여 간단한 서버 구성

// express 모듈을 설치했다고 해서 바로 사용할 수 있는 것은 아님
// server.js에서 사용을 하려면 해당 모듈을 import해야함
const express = require('express'); // express 모듈 불러오기
const app = express(); // express app 인스턴스 생성

const httpRequest = require('request');

// TODO: dotenv
require("dotenv").config(); // 모듈 불러오기

const clientID = process.env.secretId;
const clientSecret = process.env.secretPassword;





// 미들웨어 설정
app.use(express.static('public'));// 정적인 자원(static)은 public 폴더에 있다!!
app.use(express.json());// 역직렬화 처리용 모듈

// 127.0.0.1:3000/ 경로(Root)로 접근했을 때 동작시킬 핸들러
app.get('/', (request, response) => {
    response.sendFile('index.html');
});

// TODO: 그 외에 언어 감지, 언어 번역 요청시 동작할 핸들러

// 127.0.0.1:3000/detect 경로로 브라우저가 접근 시 동작할 핸들러
app.post('/detect', (request, response) => {
    console.log(request.body);

    // 언어 감지 요청을 위한 요청 메시지 구성정보
    // 1. URL
    const url = 'https://openapi.naver.com/v1/papago/detectLangs';

    // 2. Body, Header 등 데이터
    const options = {
        url,
        form: request.body,
        headers: {
            'Content-Type': 'application/json',
            'X-Naver-Client-Id': clientID,
            'X-Naver-Client-Secret': clientSecret,
        }
    }

    httpRequest.post(options, (error, httpResponse, body) => {
        if (!error && response.statusCode === 200) {
            response.send(body); // 서버가 클라이언트로 데이터를 응답
        }
    });
});

// 127.0.0.1 === localhost 동일
// 언어 번역 요청 부분 localhost:3000/translate
app.post('/translate', (request, response) => {
    const url = 'https://openapi.naver.com/v1/papago/n2mt';
    console.log(request.body);
    // 2. Body, Header 등 데이터
    const options = {
        url,
        form: request.body,
        headers: {
            'Content-Type': 'application/json',
            'X-Naver-Client-Id': clientID,
            'X-Naver-Client-Secret': clientSecret,
        }
    }

    httpRequest.post(options, (error, httpResponse, body) => {
        if (!error && response.statusCode === 200) {
            response.send(body); // 서버가 클라이언트로 데이터를 응답
        }
    });
})

const port = 3000;
app.listen(port,
    () =>
        console.log(`http://127.0.0.1:3000/ app listening on port ${3000}`));